/** Automatically generated file. DO NOT MODIFY */
package net.qiujuer.genius;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}